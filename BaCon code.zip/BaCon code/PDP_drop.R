
PDP_labelSwap <- function(Robject, label1, label2)
{ # assumes Robject is not a matrix
  ind1 <- Robject == label1
  ind2 <- Robject == label2
  Robject[ind1] <- label2
  Robject[ind2] <- label1
  
  Robject
}

PDP_positionSwap <- function(Robject, pos1, pos2)
{
  # if Robject is a matrix, assumes columns need to be swapped
  flag <- is.matrix(Robject)
  
  if (flag)
    {
    buffer <- Robject[,pos1]
    Robject[,pos1] <- Robject[,pos2]
    Robject[,pos2] <- buffer
  }
  
  if (!flag)
  {
    buffer <- Robject[pos1]
    Robject[pos1] <- Robject[pos2]
    Robject[pos2] <- buffer
  }
  
  
  Robject
}

PDP_clip <- function(Robject, G)
{
  # if Robject is a matrix, assumes columns need to be swapped
  flag <- is.matrix(Robject)
  
  if (flag)
  {Robject <- Robject[,1:G]
  }
  
  if (!flag)
  {Robject <- Robject[1:G]
  }
  
  Robject
}

PDP_recompute <- function(tmp.parm)
{
  tmp.parm$clust$N <- tmp.parm$n * tmp.parm$clust$G
  tmp.parm$clust$s.v <- as.vector(tmp.parm$clust$s.mt)
  
  tmp.parm$clust$n.vec <- array(,tmp.parm$clust$K)
  for (ss in 1:tmp.parm$clust$K)
  {tmp.parm$clust$n.vec[ss] <- sum(tmp.parm$clust$s.v==ss)
  }
  
  tmp.parm
}

PDP_bookKeep <- function(star_parm)
{
  star_parm$trig_1 <- sort(which(star_parm$clust$C.m.vec==0))
  star_parm$non_trig_1 <- sort(which(star_parm$clust$C.m.vec>0))
  
  star_parm$nonCompliant_1 <- NULL
  
  if (length(star_parm$trig_1)>0)
    {star_parm$nonCompliant_1 <- star_parm$trig_1[colSums(sapply(star_parm$trig_1, "<", star_parm$non_trig_1))  > 0]
    star_parm$Compliant_1 <- setdiff(star_parm$trig_1, star_parm$nonCompliant_1)  
    }
  
  flag <- length(star_parm$nonCompliant_1)>0
  
  while (flag)
    {old.Cluster <- star_parm$nonCompliant_1[1]
      new.Cluster <- max(star_parm$non_trig_1)
      #
      star_parm$trig_1 <- sort(PDP_labelSwap(Robject=star_parm$trig_1, label1=old.Cluster, label2=new.Cluster))
      star_parm$non_trig_1 <- sort(PDP_labelSwap(Robject=star_parm$non_trig_1, label1=old.Cluster, label2=new.Cluster))
      
      star_parm$nonCompliant_1 <- star_parm$trig_1[colSums(sapply(star_parm$trig_1, "<", star_parm$non_trig_1))  > 0]
      star_parm$Compliant_1 <- setdiff(star_parm$trig_1, star_parm$nonCompliant_1)
      flag <- length(star_parm$nonCompliant_1)>0
      
      star_parm$clust$c.v <- PDP_labelSwap(Robject=star_parm$clust$c.v, label1=old.Cluster, label2=new.Cluster)
      
      star_parm$clust$C.m.vec <- PDP_positionSwap(Robject=star_parm$clust$C.m.vec, pos1=old.Cluster, pos2=new.Cluster)
      
      star_parm$clust$s.mt <- PDP_positionSwap(Robject=star_parm$clust$s.mt, pos1=old.Cluster, pos2=new.Cluster)
        
      } # end while flag
  
  ## CLIP
  
  star_parm$clust$G <- sum(star_parm$clust$C.m.vec>0)
  star_parm$clust$C.m.vec <- PDP_clip(Robject=star_parm$clust$C.m.vec, G=star_parm$clust$G)
  star_parm$clust$s.mt <- PDP_clip(Robject=star_parm$clust$s.mt, G=star_parm$clust$G) 

  star_parm <- PDP_recompute(star_parm)
  
  star_parm
    
}

