
fn.gen.X <- function(true_parm, p, n)
    {
    true_parm$prior$Q_star.mt <- Q <- array(,c(true_parm$clust$K,true_parm$clust$K))
    
    true_parm$prior$Q_alpha <- 1
    
    for (jj in 1:true_parm$clust$K)
    	{true_parm$prior$Q_star.mt[jj,] <- rgamma(n=true_parm$clust$K, shape=true_parm$prior$Q_alpha)
    	true_parm$prior$Q_star.mt[jj,] <- true_parm$prior$Q_star.mt[jj,]/sum(true_parm$prior$Q_star.mt[jj,])
    	}
    
    true_parm$prior$Q.mt <- true_parm$r * diag(true_parm$clust$K) + (1-true_parm$r) * true_parm$prior$Q_star.mt
    	
    
    ####################
    
    data <- NULL
    data$K0 <- true_parm$K0
    data$raw.X <- true_parm$X <- array(,c(n,p))
    
    true_parm$inverse_psi.mt <- true_parm$psi.mt <- array(,c(p,true_parm$clust$K))
    
    for (gg in 1:true_parm$clust$G)
    	{indx.g <- which(true_parm$clust$c.v==gg)
    	for (ss in 1:true_parm$clust$K)
    		{indx.s <- which(true_parm$clust$s.mt[,gg]==ss,arr.ind=TRUE)
    	
    		if (length(indx.s) > 0)
    			{x.v <- sample(1:true_parm$clust$K, size=length(indx.s)*true_parm$clust$C.m.vec[gg], replace=TRUE, prob=true_parm$prior$Q.mt[ss,])
    
    			true_parm$X[indx.s,indx.g] <- x.v
    			}
    		}
    
    	}
    
    data$raw.X = true_parm$X
    
    
    data$p <- p
    
    data$min_r <- .81
    data$max_r <- 1
    
    data$G.max <- round(data$p/2)
    
    data$n = n
    
    list(true_parm, data)
    
    }

