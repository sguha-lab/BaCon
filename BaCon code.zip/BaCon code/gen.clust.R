
fn.gen_clust <- function(K0, p, n)
    {
    true_parm <- NULL
    
    true_parm$d <- 1/3
    
    true_parm$clust <- NULL
    true_parm$clust$c.v <- array(,p)
    true_parm$clust$c.v[1] <- 1
    true_parm$clust$C.m.vec <- 1
    true_parm$clust$G <- 1
    true_parm$b1 <- 20
    
    for (xx in 2:p)
    	{prob.v <- true_parm$clust$C.m.vec - true_parm$d
    	prob.v <- c(prob.v, (true_parm$b1 + true_parm$clust$G*true_parm$d))
    	new.c <- sample(1:(true_parm$clust$G+1), size=1, prob=prob.v)
    
    	true_parm$clust$c.v[xx] <- new.c
    	new.flag <- (new.c > true_parm$clust$G)
    
    	if (new.flag)
    		{true_parm$clust$G <- true_parm$clust$G + 1
    		true_parm$clust$C.m.vec <- c(true_parm$clust$C.m.vec, 1)
    		}
    	if (!new.flag)
    		{true_parm$clust$C.m.vec[new.c] <- true_parm$clust$C.m.vec[new.c] + 1
    		}
    	}
    
    tmp.mat <- array(0,c(p,p))
    
    for (jj in 1:true_parm$clust$G)
    	{indx.jj <- which(true_parm$clust$c.v==jj)
    	tmp.mat[indx.jj,indx.jj] <- 1
    	}
    
    true_parm$clust$nbhd.matrix <- tmp.mat
    
    true_parm$N <- n*true_parm$clust$G
    true_parm$clust$K <- K0 
    
    true_parm$prior <- NULL
    true_parm$prior$G0.v <- c(2,5)
    true_parm$prior$G0.v <- true_parm$prior$G0.v / sum(true_parm$prior$G0.v)
    
    true_parm$clust$s.v <- sample(1:true_parm$clust$K, size=true_parm$N, replace=TRUE, true_parm$prior$G0.v)
    true_parm$clust$n.vec <- as.numeric(summary(as.factor(true_parm$clust$s.v)))
    
    true_parm$clust$s.mt <- matrix(true_parm$clust$s.v, nrow=n)
    
    true_parm$clust$phi.v <- 1:K0
    true_parm$K0 = K0
    
    true_parm
    }