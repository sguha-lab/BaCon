

fn.Dist <- function(parm)
{
  
  tmp.mat <- array(0,c(parm$clust$p,parm$clust$p))
  
  for (jj in 1:parm$clust$G)
  {indx.jj <- which(parm$clust$c.v==jj)
  tmp.mat[indx.jj,indx.jj] <- 1
  }
  
  parm$Dist.mt = tmp.mat
  
  parm
}



fn.init.clusters <- function(parm, data)
{	
	options(warn=0)
	tmp2 <- kmeans(t(parm$clust$X), iter.max=1000, centers=parm$G.max, nstart=2)
	options(warn=2)
	#
	parm$clust$c.v <- tmp2$cluster
	parm$clust$G <- length(tmp2$size)

	parm$clust$C.m.vec <- array(,parm$clust$G)
	
	parm$clust$s.mt <- array(, c(parm$n,parm$clust$G))
	
	for (g in 1:parm$clust$G)
	  {I.g <- (parm$clust$c.v==g)
	  parm$clust$C.m.vec[g] <- m.g <- sum(I.g)
	
	  x.g <- parm$clust$X[,I.g]
	  if (m.g > 1)
	    {parm$clust$s.mt[,g] <- apply(x.g,1,Mode)
	    }
	  if (m.g == 1)
	    {parm$clust$s.mt[,g] <- x.g
	    }
	}

	parm$clust$C.m0 <- parm$clust$p - sum(parm$clust$C.m.vec)
	
	# start from PDP model with d=0 (i.e DP)
	parm$clust$d <- 0
	
	parm$clust$K <- data$K0
	
	parm$clust$N <- parm$clust$G * parm$n
	
	parm$clust$s.v <- as.vector(parm$clust$s.mt)
	parm$clust$phi.v <- 1:parm$clust$K
	
	parm$clust$n.vec <- as.numeric(summary(as.factor(parm$clust$s.v)))

	parm
}


Mode <- function(x) 
{
  ux <- unique(x)
  ux[which.max(tabulate(match(x, ux)))]
}


fn.suff.stat <- function(parm)
{
  # sufficient stat for c updates
  parm$W.ar <- array(,c(parm$n,parm$clust$p,parm$clust$K))
  
  for (i in 1:parm$n)
  {X.i <- parm$clust$X[i,]
  
  for (j in 1:parm$clust$K)
  {parm$W.ar[i,,j] <- as.numeric(X.i==j)
  }
  }
  
  parm
}


fn.eda <- function(parm, data)
{	
	
	parm <- fn.init.clusters(parm, data)

	parm <- fn.assign.priors(parm, data)

	parm$clust$tau.v <- runif(n=parm$clust$K,min=data$min_tau, max=data$max_tau)

	parm <- fn.hyperparameters(data, parm)

  parm

	}


fn.trans <- function(parm)
	{parm$clust$T <- array(0,c(parm$clust$K,parm$clust$K))

	for (g in 1:parm$clust$G)
		{I.g <- (parm$clust$c.v==g)

		X.g <- parm$clust$X[,I.g]
		
		for (u in 1:parm$clust$K)
			{rows.u <- parm$clust$s.mt[,g]==u
			for (t in 1:parm$clust$K)
				{parm$clust$T[u,t] <- parm$clust$T[u,t] + sum(rows.u * (X.g==t))
				}
			}
		}

	if (sum(parm$clust$T) != parm$n*parm$clust$p)
		{stop("Error in transition parm$clust$T")
		}
	parm
	}

fn.lbeta <- function(v)
	{sum(lgamma(v)) - lgamma(sum(v))
	}


fn.gen_Q_tau <- function(parm)
	{parm$clust$Q <- parm$clust$Q.star <- array(NA,c(parm$clust$K,parm$clust$K))

	for (s in 1:parm$clust$K)
		{
		# generating parm$clust$tau.v[s]

		log_prob.v <- lchoose(parm$clust$T[s,s], 0:parm$clust$T[s,s])
		
		vec.mt <- array(parm$prior$Q_alpha/parm$clust$K, c(parm$clust$K,(1+parm$clust$T[s,s])))
		vec.mt <- vec.mt + parm$clust$T[s,]
		vec.mt[s,] <- vec.mt[s,] - 0:parm$clust$T[s,s]
		vec <- apply(vec.mt, 2, fn.lbeta)
		log_prob.v <- log_prob.v + vec

		log2_prob.v <- log_prob.v

		v1 <- 0:parm$clust$T[s,s] + 1
		v2 <- sum(parm$clust$T[s,]) - 0:parm$clust$T[s,s] + 1
		v.mt <- cbind(v1,v2)
		log_prob.v <- log_prob.v + apply(v.mt,1,fn.lbeta)
    
		# trapping an infrequent overflow warning
		v3 = try(pbeta(parm$prior$min_tau, v1, v2, log=TRUE, lower=FALSE))
		log_prob.v <- log_prob.v + v3
		
		log_prob.v <- log_prob.v - max(log_prob.v)
		v.s <- sample(0:parm$clust$T[s,s], size=1, prob=exp(log_prob.v))

		u.min <- pbeta(parm$prior$min_tau, (v.s+1), (sum(parm$clust$T[s,]) - v.s + 1))
		flag <- abs(1-u.min) < 1e-5

		if (flag)
			{parm$clust$tau.v[s] <- parm$prior$min_tau 
			}
		if (!flag)
			{u.s <- runif(n=1, min=u.min)
			parm$clust$tau.v[s] <- qbeta(u.s, (v.s+1), (sum(parm$clust$T[s,]) - v.s + 1))
			}
		
		###############################

		# generating parm$clust$Q.star

		log2_prob.v <- log2_prob.v + (0:parm$clust$T[s,s])*log(parm$clust$tau.v[s]/(1-parm$clust$tau.v[s]))
		log2_prob.v <- log2_prob.v - max(log2_prob.v)
		v2.s <- sample(0:parm$clust$T[s,s], size=1, prob=exp(log2_prob.v))

		dir.v <- parm$prior$Q_alpha/parm$clust$K + parm$clust$T[s,] 
		dir.v[s] <- dir.v[s] - v2.s

		Z_s <- rgamma(n=parm$clust$K, shape=dir.v)
		parm$clust$Q.star[s,] <- Z_s/sum(Z_s)

		parm$clust$Q[s,] <- (1-parm$clust$tau.v[s])*parm$clust$Q.star[s,]
		parm$clust$Q[s,s] <- parm$clust$Q[s,s] + parm$clust$tau.v[s]		

		}
	
	parm$clust$log.Q <- log(parm$clust$Q)

	if (abs(sum(parm$clust$Q) - parm$clust$K) > 1e-10)
		{stop("Error in parm$clust$Q")
		}

	parm

	}

fn.trans_single <- function(parm, x, v)
	{parm$clust$T_single <- array(,c(parm$clust$K,parm$clust$K))

	for (u in 1:parm$clust$K)
		{rows.u <- v==u
		for (t in 1:parm$clust$K)
			{parm$clust$T_single[u,t] <- sum(rows.u * (x==t))
			}
		}

	if (sum(parm$clust$T_single) != parm$n)
		{stop("Error in transition parm$clust$T_single")
		}
	parm
	}




fn.quality.check <- function(parm)
	{err <- 0
	

	if (ncol(parm$clust$s.mt) != parm$clust$G)
		{err <- 4
		}

	
	if ((sum(parm$clust$C.m.vec) + parm$clust$C.m0) != parm$clust$p)
		{err <- 8
		}

	if (length(parm$clust$n.vec) != parm$clust$K) 
		{err <- 9
		}

	if (length(parm$clust$phi.v) != parm$clust$K) 
		{err <- 10
		}

	if (sum(parm$clust$n.vec) != parm$clust$N)
		{err <- 11
		}


	err
	}


fn.funky <- function(s,t)
	{# on log scale 
	lgamma(s+t) - lgamma(s) 
	}

fn.d <- function(d, parm)
	{
	
	log.lik <- sum(log(parm$clust$b1 + (1:(parm$clust$G-1))*d)) - fn.funky((parm$clust$b1+1), (parm$clust$p-1)) + sum(fn.funky((1-d), (parm$clust$C.m.vec-1)))

	log.lik
	}




fn.PDP.discount <- function(data, parm, w=.01)
	{
	
	## 1/w must be an integer

	d.v <- seq(0,1,by=w)
	len <- length(d.v)
	d.v <- d.v[-len]
	len <- len-1

	log.lik.v <- sapply(d.v, fn.d, parm)
	# putting 1/2 prior mass on 0 and remaining spread uniformly on positive points in d.v
	log.p.v <- log(.5) + c(0,  rep(-log(len-1),(len-1)))
	
	log.post.v <- log.lik.v + log.p.v
	log.post.v <- log.post.v - max(log.post.v)

	log.post.2 <- c(log.post.v[1], log(sum(exp(log.post.v[-1]))))

  parm$log.BF <- log.post.2[2]-log.post.2[1]
		
	post.v <- exp(log.post.v)
	post.v <- post.v/sum(post.v)

	prop.d <- sample(d.v, size=1, prob=post.v)
	
	if (prop.d > 0)
		{prop.d <- runif(n=1, min=(prop.d-w), max=(prop.d+w))
		}

	if (prop.d != parm$clust$d)
		{
		# MH ratio for independent proposals 

		log.ratio <- fn.d(d=prop.d, parm) - fn.d(d=parm$clust$d, parm)
		prob <- min(1, exp(log.ratio))
		flip <- rbinom(n=1, size=1, prob=prob)
		if (flip==1)
			{parm$clust$d <- prop.d
			}
		}

	parm
	
	}

L.b1 <- function(b1, parm)
{

  log.lik <- sum(log(b1 + (1:(parm$clust$G-1))*parm$clust$d)) - fn.funky((b1+1), (parm$clust$p-1)) + sum(fn.funky((1-parm$clust$d), (parm$clust$C.m.vec-1)))
  
  log.lik
}

log.post.log_b1 <- function(log_b1, parm)
{
  
  L.b1(exp(log_b1), parm) + dnorm(log_b1, mean=parm$log_b1$mean, sd=parm$log_b1$sd, log=TRUE)
  
}

deri_post.log_b1 <- function(log_b1, parm, eps=parm$log_b1$sd/100)
{
  
  val1  <- log.post.log_b1((log_b1+eps/2), parm)
  val2 <- log.post.log_b1((log_b1-eps/2), parm)
  
  (val1-val2)/eps
}

deri2_post.log_b12 <- function(log_b1, parm, eps=parm$log_b1$sd/100)
{
  
  val1  <- deri_post.log_b1((log_b1+eps), parm)
  val2 <- deri_post.log_b1((log_b1-eps), parm)
  
  (val1-val2)/eps/2
}




fn.PDP.precision <- function(data, parm)
{
  
  log_b1_sd <- parm$mh_log_b1_const/sqrt(-deri2_post.log_b12(log_b1=log(parm$clust$b1), parm, eps=parm$log_b1$sd/100))
  
  new.parm <- parm
  u <- runif(n=1)
  new.parm$clust$b1 <- exp(qnorm(u,mean=log(parm$clust$b1),sd=parm$log_b1$sd))
  
  log.ratio <- log.post.log_b1(log_b1=new.parm$clust$b1, parm) - log.post.log_b1(log_b1=parm$clust$b1, parm)
  log.ratio <- min(log.ratio,0)
  b1_flip <- rbinom(n=1,size=1,prob=exp(log.ratio))
  
  if (b1_flip==1)
  {parm <- new.parm
  }
  
  parm$clust$b1_flip <- b1_flip
  
  parm
  
}


fn.PDP.hyperparameters <- function(data, parm)
{

parm <- fn.PDP.discount(data, parm, w=.01)

parm <- fn.PDP.precision(data, parm)
  
parm
}


fn.assign.priors <- function(parm, data)
	{
	parm$prior <- NULL
	parm$prior$min_tau <- data$min_tau
	parm$prior$max_tau <- 1

	parm$prior$Q_alpha <- parm$clust$K
		
	parm
	}



fn.gen.clust <- function(parm, data, max.row.nbhd.size, max.col.nbhd.size, row.frac.probes, col.frac.probes)
	{

  parm <- fn.eda(parm, data)
	
	parm <- fn.hyperparameters(data, parm)
	
	parm <- fn.suff.stat(parm)

	parm <- fn.element.DP(data, parm, max.row.nbhd.size, row.frac.probes=1)
	
	parm

	}



fn.init <- function(data, max.row.nbhd.size, max.col.nbhd.size, row.frac.probes, col.frac.probes)
	{
	parm <- NULL

	parm$n <- data$n 
	
	parm$clust <- NULL
	parm$clust$p <- ncol(data$raw.X)
	parm$G.max <- round(parm$clust$p/4)
	
	# mass paramater of column
	parm$clust$b1 <- parm$G.max/log(parm$clust$p)
	
	# prior on log scale for parm$clust$b1
	parm$log_b1$mean <- log(data$G.max/log(parm$clust$p))
	parm$log_b1$sd <- 1/sqrt(data$G.max)
	
	# For HM steps
	parm$mh_log_b1_const <- 1.5

	# For cluster delta-neighborhoods

	parm$col.delta <- .2

	# delta-neighborhood threshold for elements
	parm$row.delta <- .1
	
	parm$clust$X <- data$raw.X
	
	# generating R- and C- clusters

	parm <- fn.gen.clust(parm, data, max.row.nbhd.size, max.col.nbhd.size, row.frac.probes, col.frac.probes)

	parm

	}



fn.hyperparameters <- function(data, parm)
	{
	# transition counts
	parm <-  fn.trans(parm)

	# matrix Q of transition probabilities
	parm <- fn.gen_Q_tau(parm)

	parm

	}


########################################

fn.iter <- function(data, parm, max.row.nbhd.size, max.col.nbhd.size, row.frac.probes, col.frac.probes, prob.compute.col.nbhd)
	{

  parm <- PDP_fn.main(parm, data, col.frac.probes, prob.compute.col.nbhd, max.col.nbhd.size)
  
  parm <- fn.element.DP(data, parm, max.row.nbhd.size, row.frac.probes)
  
  err <- fn.quality.check(parm)
  if (err > 0)
  {stop(paste("parm failed QC", text, ": err=",err))
  }
  
  parm <- fn.PDP.hyperparameters(data, parm)
	
  parm <- fn.hyperparameters(data, parm)
	
	parm <- fn.suff.stat(parm)

	err <- fn.quality.check(parm)
	if (err > 0)
		{stop(paste("parm failed QC", text, ": err=",err))
	}

	parm

	}




fn.mcmc <- function(text, input.All.Stuff, do.burn, do.postburn, n.burn, n.postburn, data, max.row.nbhd.size, max.col.nbhd.size, row.frac.probes, col.frac.probes, prob.compute.col.nbhd, true_parm)
	{
  
  # note: concordance parameter r is called "tau" during model fitting
  data$min_tau <- data$min_r
  data$max_tau <- data$max_r

  if (do.burn)
  {
	# initialize
  parm <- fn.init(data, max.row.nbhd.size, max.col.nbhd.size, row.frac.probes, col.frac.probes)
	init.parm <- parm
	
	# burnin
	
	for (cc in 1:n.burn)
		{parm <- fn.iter(data, parm, max.row.nbhd.size, max.col.nbhd.size, row.frac.probes, col.frac.probes, prob.compute.col.nbhd)
		
		if (cc %% 10 == 0)
			{print(paste(text, "ITER = ",cc,date(),"***********"))
		  }
		} # end for loop
	
	
	local.All.Stuff <- NULL
	local.All.Stuff$parm <- parm
	local.All.Stuff$n.burn <- n.burn
	
  } # end if (do.burn)

	
	##########################################

  # post-burnin
  if (do.postburn)
  { 
    
  parm <- input.All.Stuff$parm
  init.parm <- input.All.Stuff$init.parm
    
	local.All.Stuff <- NULL
	
	local.All.Stuff$d.v <- local.All.Stuff$G.v <- local.All.Stuff$b1.v <- array(,n.postburn)
	local.All.Stuff$b1.flip.v  <- array(0,n.postburn)
	
	local.All.Stuff$PDP_new.flag  <- 0
	
	local.All.Stuff$Q.mt <- array(0,c(parm$clust$K,parm$clust$K))

  flip.count <- 0

	local.All.Stuff$log.BF.v <- local.All.Stuff$mean.taxicab.v <- local.All.Stuff$mean.euclid.v <- array(0,n.postburn)
	
	local.All.Stuff$SqFrob.v <- array(,n.postburn)
	
	local.All.Stuff$tau.mt <- array(0,c(parm$clust$K,n.postburn))
	
	for (cc in 1:n.postburn)
		{parm <- fn.iter(data, parm, max.row.nbhd.size, max.col.nbhd.size, row.frac.probes, col.frac.probes, prob.compute.col.nbhd)
		
		local.All.Stuff$G.v[cc] <- parm$clust$G

		local.All.Stuff$d.v[cc] <- parm$clust$d
		local.All.Stuff$b1.v[cc] <- parm$clust$b1
		local.All.Stuff$b1.flip.v[cc]  <- parm$clust$b1_flip

		local.All.Stuff$PDP_new.flag <- local.All.Stuff$PDP_new.flag + parm$clust$PDP_new.flag
		
		parm = fn.Dist(parm)
		local.All.Stuff$meanDist.mt = local.All.Stuff$meanDist.mt + parm$Dist.mt
		
		local.All.Stuff$SqFrob.v[cc] <- mean((parm$Dist.mt - true_parm$clust$nbhd.matrix)^2)
		  
		if (cc %% 10 == 0)
			{print(paste(text, "ITER = ",cc,date(),"***********"))
			}

		local.All.Stuff$log.BF.v[cc] <- mean(parm$log.BF)

		local.All.Stuff$Q.mt <- local.All.Stuff$Q.mt + parm$clust$Q

		local.All.Stuff$tau.mt[,cc] <- parm$clust$tau.v

		} # end for loop in cc

	local.All.Stuff$Q.mt <- local.All.Stuff$Q.mt/n.postburn


	local.All.Stuff$parm <- parm
	local.All.Stuff$init.parm <- init.parm
	
	# lower bound for log_BF of true hypothesis for d versus 
	# alternative hypothesis

	local.All.Stuff$lower_log.BF <- mean(local.All.Stuff$log.BF.v)
	
	local.All.Stuff$PDP_new.flag <- local.All.Stuff$PDP_new.flag / n.postburn
	
	local.All.Stuff$meanDist.mt = local.All.Stuff$meanDist.mt/n.postburn
	
	local.All.Stuff$n.postburn <- n.postburn
	
  } # end if (do.postburn)
  

	local.All.Stuff
	}

