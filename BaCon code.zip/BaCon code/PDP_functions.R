

PDP_all_consistency <- function(parm, txt, checkNbhds=FALSE)
{
  
  err <- PDP_fn.compact.consistency.check(parm, checkNbhds)
  if (err > 0)
  {stop(paste(txt, ": parm failed consistency check: err=",err))
  }
  
}

PDP_fn.compact.consistency.check <- function(tmp_parm, checkNbhds=FALSE)
  {err <- 0

  if (max(sort(unique(tmp_parm$clust$c.v))) != tmp_parm$clust$G)
    {err <- 1
    }

  if (sum(tmp_parm$clust$C.m.vec==0) > 0)
    {err <- 1.5
  }

  err <- PDP_fn.consistency.check(tmp_parm, checkNbhds)

  err
  }


PDP_fn.consistency.check <- function(tmp_parm, checkNbhds=FALSE)
  {err <- 0
  

  if (sum(tmp_parm$clust$C.m.vec) + tmp_parm$clust$C.m0 != tmp_parm$clust$p)
    {err <- 4
    }
  
  if (ncol(tmp_parm$clust$X) != tmp_parm$clust$p)
    {err <- 5
    }

  if (length(tmp_parm$clust$n.vec) != tmp_parm$clust$K) 
    {err <- 9
    }

  if (length(tmp_parm$clust$phi.v) != tmp_parm$clust$K) 
    {err <- 10
    }

  if (length(tmp_parm$clust$C.m.vec) != tmp_parm$clust$G) 
    {err <- 9.5
  }
  
  if (checkNbhds & (!is.null(tmp_parm$clust$col_post.prob.mt)))
    {
    err <- c(err,20*(nrow(tmp_parm$clust$col_post.prob.mt) != tmp_parm$clust$G))
    err <- c(err,20*(ncol(tmp_parm$clust$col_post.prob.mt) != tmp_parm$clust$p))
    #
    err <- c(err,25*sum(abs(colSums(tmp_parm$clust$col_post.prob.mt)-1) >  1e-5))
    #
    err <- c(err,30*(nrow(tmp_parm$clust$logLik.mt) != tmp_parm$clust$G))
    err <- c(err,30*(ncol(tmp_parm$clust$logLik.mt) != tmp_parm$clust$p))
  }

  
  max(err)
  }


PDP_handleNewCuster <- function(tmp_parm, news, new.count)
{
  tmp_parm$clust$G <- tmp_parm$clust$G + 1 
  
  tmp_parm$clust$C.m.vec <- c(tmp_parm$clust$C.m.vec, new.count) 
  
  tmp_parm$clust$s.v <- c(tmp_parm$clust$s.v, news$s.v.k)
  
  tmp_parm$clust$s.mt <- matrix(tmp_parm$clust$s.v, nrow=tmp_parm$n)
  
  tmp_parm$clust$n.vec <- tmp_parm$clust$n.vec + news$n.vec.k
  
  tmp_parm$clust$N <- sum(tmp_parm$clust$n.vec) 

  tmp_parm
}


PDP_fn.check.nbhd <- function(tmp_parm)
{
  max_dist.v <- array(,length(tmp_parm$clust$col.nbhd.k))
  
  for (zz in 1:length(tmp_parm$clust$col.nbhd.k))
  {
    v1 <- tmp_parm$clust$col_post.prob.mt[,tmp_parm$clust$col.nbhd.k[zz]]
    m1 <- matrix(tmp_parm$clust$col_post.prob.mt[,tmp_parm$clust$col.nbhd[[zz]]],ncol=length(tmp_parm$clust$col.nbhd[[zz]]))
    max_dist.v[zz] <- max(2*(1-colSums(sqrt(v1*m1))))
  }
  
  tmp_parm$clust$nbhd_max_dist <- max(max_dist.v)
  
  tmp_parm
  
}


PDP_fn.nbhd <- function(relative_I, tmp_parm, max.col.nbhd.size)
{
  if (length(relative_I)>1)
  {relative_k <- sample(relative_I, size=1)
  }
  if (length(relative_I)==1)
  {relative_k <- relative_I
  }
  
  post.prob.mt <- tmp_parm$clust$col_post.prob.mt
  
  tmp1.mt <- matrix(post.prob.mt[,relative_I], ncol = length(relative_I)) ## HOT
  tmp2.v <- post.prob.mt[,relative_k]
  tmp3.mt <- sqrt(tmp1.mt * tmp2.v) ## HOT
  H.v <-  2 * (1 - colSums(tmp3.mt))
  
  cutoff <- tmp_parm$col.delta
  flag.v <- which(H.v <= cutoff)
  relative_I.k <- relative_I[flag.v]
  
  if (length(relative_I.k) > max.col.nbhd.size) 
    {relative_I.k <- relative_I[rank(H.v, ties="random") <= max.col.nbhd.size]
  }
  
  relative_I.k <- sort(relative_I.k)
  
  relative_I <- sort(setdiff(relative_I, relative_I.k))
  relative_I <- sort(relative_I)
  
  list(relative_k, relative_I.k, relative_I)
  
}


PDP_fn.basic <- function(mat1, mat2)
{if (sum(dim(mat1)!=dim(mat2))>0)
  {stop("Unequal dimensions of the two matrices.")}
  
  sum(mat1*mat2)
}
  
PDP_fn.log.lik_gg <- function(gg, W2.ar, tmp_parm)
{
  s_gg.v <- tmp_parm$clust$s.mt[,gg]
  log.Q_gg <- tmp_parm$clust$log.Q[s_gg.v,]
  
  apply(W2.ar,2,PDP_fn.basic,log.Q_gg)
  
}

PDP_fn.log.lik <- function(col.subset, tmp_parm, cluster.subset=NULL)
{
  if (is.null(cluster.subset))
    {cluster.subset=1:tmp_parm$clust$G
    }
  
  L.mt <- array(, c(length(cluster.subset),length(col.subset)))
  
  dimm <- dim(tmp_parm$W.ar)
  dimm[2] <- length(col.subset)
  W2.ar <- array(tmp_parm$W.ar[,col.subset,],dimm)
  
  for (xx in 1:length(cluster.subset))
  {L.mt[xx,] <- PDP_fn.log.lik_gg(gg=cluster.subset[xx], W2.ar, tmp_parm)
  }	
  
  L.mt
  
}

PDP_nbhd_probs <- function(tmp_parm)
{ 
  col.subset=1:tmp_parm$clust$p
  
  tmp_parm$clust$logLik.mt <- PDP_fn.log.lik(col.subset, tmp_parm)
    
  tmp_parm <- PDP_fn.logLik_to_postProb(tmp_parm, col.subset) 
    
  tmp_parm
  
}



PDP_fn.logLik_to_postProb <- function(tmp_parm, col.subset=NULL) 
{
  if (is.null(col.subset))
    {col.subset=(1:tmp_parm$clust$p)
  }
  
  prior.prob.v <- tmp_parm$clust$C.m.vec
  small <- 1e-3 # compared to 1
  prior.prob.v[prior.prob.v < small] <- small
  
  subset_log.ss.mt <- tmp_parm$clust$logLik.mt + as.vector(log(prior.prob.v))
  
  maxx.v <- apply(subset_log.ss.mt, 2, max)
  
  subset_log.ss.mt <- t(t(subset_log.ss.mt) - maxx.v)
  subset_ss.mt <- exp(subset_log.ss.mt)
  
  col.sums.v <- colSums(subset_ss.mt)
  subset_ss.mt <- t(t(subset_ss.mt)/col.sums.v)
  
  # replace zeros by "small"
  small2 <- 1e-5
  subset_ss.mt[subset_ss.mt < small2] <- small2
  
  # again normalize
  col.sums.v <- colSums(subset_ss.mt)
  subset_ss.mt <- t(t(subset_ss.mt)/col.sums.v)
  
  tmp_parm$clust$col_post.prob.mt <- subset_ss.mt
  dimnames(tmp_parm$clust$col_post.prob.mt) <- list(1:tmp_parm$clust$G, 1:length(col.subset))
  
  tmp_parm
}
  

PDP_fn.post.prob.and.delta <- function(tmp_parm, max.col.nbhd.size, col.frac.probes, justNbhds=FALSE) 
{
  
 if (!justNbhds)
 {
  
  tmp_parm <- PDP_nbhd_probs(tmp_parm)
  
 
 } # if (!justNbhds)


  ### now compute the delta-neighborhoods

  col.subset=1:tmp_parm$clust$p
  tmp_parm$clust$col.nbhd <- NULL
  tmp_parm$clust$col.nbhd.k <- NULL
   relative_I<- 1:length(col.subset)
  
  while (length(relative_I) >= 1) {
    tmp <- PDP_fn.nbhd(relative_I, tmp_parm, max.col.nbhd.size) # HOT inside function
    relative_k <- tmp[[1]]
    relative_I.k <- tmp[[2]]
    relative_I <- tmp[[3]]
    #
    tmp_parm$clust$col.nbhd <- c(tmp_parm$clust$col.nbhd, list(col.subset[relative_I.k]))
    tmp_parm$clust$col.nbhd.k <- c(tmp_parm$clust$col.nbhd.k, col.subset[relative_k])
  }
  
  tmp_parm <- PDP_fn.check.nbhd(tmp_parm)
  
  tmp_parm
}



PDP_fn.gen.new.column <- function(k, in.parm, gen.flag, rev_flag)
	{new_clust.parm <- in.parm

	c.k <- new_clust.parm$clust$c.v[k]

	s.k <- new_clust.parm$clust$s.mt[,c.k]

	new_clust.parm$news$p.v <- new_clust.parm$clust$p.v

	new_clust.parm$news$log.p.v <- new_clust.parm$clust$log.p.v

	new_clust.parm$W.k <- new_clust.parm$W.ar[,k,]
	log.ss.mt <- array(,c(new_clust.parm$clust$K, new_clust.parm$n))

	for (ss in 1:new_clust.parm$clust$K)
		{log.ss.mt[ss,] <- new_clust.parm$news$log.p.v[ss] + as.vector(new_clust.parm$W.k %*% new_clust.parm$clust$log.Q[ss,])
		}

	## marginal likelihod of new cluster

	new_clust.parm$news$log.lik <- sum(log(colSums(exp(log.ss.mt))))

	cond1 <- gen.flag
	cond2 <- (!gen.flag & rev_flag)

	if (cond1 | cond2)

	{
		## generating a new cluster's s

		dimnames(log.ss.mt) <- list(1:new_clust.parm$clust$K, 1:new_clust.parm$n)

		maxx.v <- apply(log.ss.mt, 2, max)
		log.ss.mt <- t(t(log.ss.mt) - maxx.v)
		ss.mt <- exp(log.ss.mt)

		col.sums.v <- colSums(ss.mt)
		ss.mt <- t(t(ss.mt)/col.sums.v)

		# replace zeros by "small"
		small <- 1e-5
		ss.mt[ss.mt < small] <- small

		# again normalize 
		col.sums.v <- colSums(ss.mt)
		ss.mt <- t(t(ss.mt)/col.sums.v)

		new_clust.parm$clust$post.prob.mt <- ss.mt	
		new_clust.parm$clust$log.post.prob.mt <- log(new_clust.parm$clust$post.prob.mt)

		cum.ss.mt <- apply(ss.mt, 2, cumsum)
		dimnames(cum.ss.mt) <- NULL

		if (cond1)
			{u.v <- runif(n=new_clust.parm$n)

			tmp.mt <- t(t(cum.ss.mt) > u.v)

			s.v <- new_clust.parm$clust$K + 1 - as.vector(colSums(tmp.mt)) 
			}

		if (cond2)
			{jj <- new_clust.parm$clust$G
			s.v <- new_clust.parm$clust$s.mt[,jj]
			}

		new_clust.parm$news$s.v.k <- s.v

		new_clust.parm$news$n.vec.k <- array(,new_clust.parm$clust$K)
		for (gg in 1:new_clust.parm$clust$K)
			{new_clust.parm$news$n.vec.k[gg] <- sum(s.v==gg)
			}

	} # end big if loop

		
	new_clust.parm
	}


PDP_fn.superfast <- function(parm, data)
	{

  k <- parm$k 
  I.k <- parm$I.k
  
  old.c.k <- parm$clust$c.v[I.k]
  
  parm$clust$C.m.vec.k <- array(,parm$clust$G)
  
  for (gg in 1:parm$clust$G) 
  {parm$clust$C.m.vec.k[gg] <- sum(old.c.k == gg)
  }
  
  parm$clust$C.m.vec.k.comp <- parm$clust$C.m.vec - parm$clust$C.m.vec.k
  
 
  L.v <- as.vector(PDP_fn.log.lik(col.subset=parm$k, parm))
  
  # create new potential cluster
  # and compute tmp_parm$news$log.w
  
  parm <- PDP_fn.gen.new.column(k, in.parm=parm, gen.flag=TRUE, rev_flag=FALSE)
  
  L.v <- c(L.v, parm$news$log.lik)
  
  emptied.indx <- which(parm$clust$C.m.vec==0)
  new.G <- parm$clust$G - length(emptied.indx)
  
  log.prior.v <- array(NA, (1+parm$clust$G))
  
  spread.mass <- (parm$clust$b1+new.G*parm$clust$d)/(1+length(emptied.indx))
  
  if (length(emptied.indx) >0)
  {
    log.prior.v[-emptied.indx] <- log(c((parm$clust$C.m.vec[-emptied.indx]-parm$clust$d), spread.mass))
    log.prior.v[emptied.indx] <- log(spread.mass)
  }
  
  if (length(emptied.indx) ==0)
  {log.prior.v <- log(c((parm$clust$C.m.vec-parm$clust$d), spread.mass))
  }
 
  tmp2 <- log.prior.v + L.v
  maxx <- max(tmp2)
  tmp2 <- tmp2 - maxx
  
  tmp2 <- exp(tmp2)
  
  parm$clust$post.k <- tmp2
  parm$clust$post.k <- parm$clust$post.k / sum(parm$clust$post.k)
  
  new.c.k <- sample(1:(parm$clust$G+1), size=length(I.k), replace=TRUE, prob=parm$clust$post.k)
  
    parm$clust$c.v[I.k] <- new.c.k
    
    new.count <- sum(new.c.k == (parm$clust$G+1))
    new.flag <- new.count > 0
    
    for (gg in 1:parm$clust$G)
    {count.gg <- sum(new.c.k==gg)
    parm$clust$C.m.vec[gg] <- parm$clust$C.m.vec.k.comp[gg] + count.gg
    
    }
    
      
    if (new.flag)
    {
      parm <- PDP_handleNewCuster(tmp_parm=parm, news=parm$news, new.count)
      
    }
    
    
	parm$flag.new <- as.numeric(new.flag) 
	
	err <- PDP_fn.consistency.check(parm)
	
	if (err > 0)
	{stop(paste("MH - 1: parm failed consistency check: err=",err))
	}
	
	parm
	}


PDP_fn.main <- function(parm, data, col.frac.probes, prob.compute.col.nbhd, max.col.nbhd.size)
{		
 
    PDP_all_consistency(parm, txt="MAIN FUNCTION BEGIN", checkNbhds=FALSE)
  
    parm <- fn.suff.stat(parm)

	  # compute delta-neighborhoods
	  
	  col_flip <- as.logical(rbinom(n=1,size=1,prob=prob.compute.col.nbhd))
	  
	  if (is.null(parm$clust$col.nbhd.k) | col_flip)
	    {parm <- PDP_fn.post.prob.and.delta(parm, max.col.nbhd.size, col.frac.probes)
	  }
	  
	  PDP_all_consistency(parm, txt="Nbhd calculation", checkNbhds=FALSE)
	 
	  
	  if (col.frac.probes < 1)
	  {num_nbhds <- max(1,round(col.frac.probes*length(parm$clust$col.nbhd.k)))
	  parm$col.subset.I <- sort(sample(1:length(parm$clust$col.nbhd.k), size=num_nbhds))
	  }
	  
	  if (col.frac.probes == 1)
	  {parm$col.subset.I <- 1:length(parm$clust$col.nbhd.k)
	  }
	
	new.flag.v <- NULL
	parm$j.subset <- NULL
 
	for (cc in parm$col.subset.I)
	{previous.parm <- parm
	
  parm$k <- parm$clust$col.nbhd.k[cc]
	parm$I.k <- parm$clust$col.nbhd[[cc]]
	parm$j.subset <- c(parm$j.subset, parm$I.k)
	
	parm$clust$p.v <- rgamma(n=parm$clust$K, shape=(parm$clust$n.vec+1))
	parm$clust$p.v <- parm$clust$p.v / sum(parm$clust$p.v)
	parm$clust$log.p.v <- log(parm$clust$p.v)
	
  parm <- PDP_fn.superfast(parm, data)
	  
	new.flag.v <- c(new.flag.v, parm$flag.new)
	
	PDP_all_consistency(parm, txt="for cc loop", checkNbhds=FALSE)

	} # END BIG LOOP:for (cc ..
	
	parm$clust$PDP_new.flag <- mean(new.flag.v)
	
	## Drop empty group clusters: includes consistency check

	parm <- PDP_bookKeep(star_parm=parm)
	
	PDP_all_consistency(parm, txt="PDP_bookKeep", checkNbhds=FALSE)
	
	parm <- fn.suff.stat(parm)

	parm
	}



