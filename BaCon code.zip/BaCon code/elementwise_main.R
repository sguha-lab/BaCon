


fn1.update.row.objects <- function(parm)
	{
	
	parm$clust$s.mt <- array(parm$clust$s.v, c(parm$n,parm$clust$G))

	parm$clust$theta.v <- as.vector(parm$clust$s.mt)

	parm$clust$n.vec <- array(,parm$clust$K)

	for (s in 1:parm$clust$K)
		{parm$clust$n.vec[s] <- sum(parm$clust$s.v==s)
		}

	parm$clust$n0 <- sum(parm$clust$s.v==0)

	parm
	}


fn2.update.row.objects <- function(parm)
	{
	
	# sufficient stat for s updates
  parm$Y <- array(,c(parm$n,parm$clust$G,parm$clust$K))
  
  for (g in 1:parm$clust$G)
  {I.g <- (parm$clust$c.v==g)
  m.g <- parm$clust$C.m.vec[g]
  
  X.g <- array(parm$W.ar[,I.g,],c(parm$n,m.g,parm$clust$K))
  
  parm$Y[,g,] <- apply(X.g, c(1,3), sum)
  }
  
	parm$clust$N <- parm$n*parm$clust$G

	parm$Y.flat <- array(,c(parm$clust$N,parm$clust$K))
	for (j in 1:parm$clust$K)
			{parm$Y.flat[,j] <- as.vector(parm$Y[,,j])
			}

	parm$Y <- parm$Y.flat


	#####################

	parm <- fn1.update.row.objects(parm)

	parm
	}



fn.element.DP <- function(data, parm, max.row.nbhd.size, row.frac.probes)
{ 	

	parm <- fn2.update.row.objects(parm)

	parm <- element_fn.fast.DP(parm, max.row.nbhd.size, row.frac.probes)

	parm <- fn1.update.row.objects(parm)

  	parm
}



