


element_fn.log.lik <- function(ss, Y.mt, parm)
{log.lik <- as.vector(Y.mt %*% parm$clust$log.Q[ss,])

log.lik
}



element_fn.compact_consistency.check <- function(parm)
	{err <- 0

	if (max(unique(parm$clust$s.v)) != parm$clust$K)
		{err <- 1
		}
	
	err <- element_fn.consistency.check(parm)

	err
	}


element_fn.consistency.check <- function(parm)
	{err <- 0
	
	if (!is.null(parm$clust$row.nbhd))
		{if (sum(unlist(lapply(parm$clust$row.nbhd, length))) != length(parm$row.subset.I))
			{err <- 2
			}
		}

	if (sum(parm$clust$n.vec)  != parm$clust$N)
		{err <- 4
		}

	if (length(parm$clust$n.vec) != parm$clust$K)
		{err <- 5
		}

	if (length(parm$clust$phi.v) != parm$clust$K)
		{err <- 6
		}

	err
	}


fast_element_fn.nbhd <- function(relative_I, parm, max.row.nbhd.size)
{
  if (length(relative_I)>1)
    {relative_k <- sample(relative_I, size=1)
    }
  if (length(relative_I)==1)
    {relative_k <- relative_I
    }
  
  post.prob.mt <- parm$clust$element_subset_post.prob.mt
  
  tmp1.mt <- matrix(post.prob.mt[,relative_I], ncol=length(relative_I))
  tmp2.v <- post.prob.mt[,relative_k]
  tmp3.mt <- sqrt(tmp1.mt * tmp2.v)
  H.v <-  2*(1-colSums(tmp3.mt))
  
  cutoff <- parm$row.delta
  flag.v <- which(H.v <= cutoff)
  relative_I.k <- relative_I[flag.v]
  
  if (length(relative_I.k) > max.row.nbhd.size)
    {#cutoff <- quantile(H.v[flag.v], probs=max.row.nbhd.size/length(relative_I.k))
    #relative_I.k <- relative_I[which(H.v <= cutoff)]
    relative_I.k <- relative_I[rank(H.v, ties="random") <= max.row.nbhd.size]
    }
  
  relative_I.k <- sort(relative_I.k)
  
  relative_I <- sort(setdiff(relative_I, relative_I.k))
  relative_I <- sort(relative_I)
  
  list(relative_k, relative_I.k, relative_I)
}


fast_element_fn.post.prob.and.delta <- function(parm, max.row.nbhd.size)
  
{

  prior.prob.v <- as.vector(parm$clust$n.vec)
  small <- 1e-3 # compared to 1
  prior.prob.v[prior.prob.v < small] <- small
 
  subset_log.ss.mt <- array(,c(parm$clust$K, length(parm$row.subset.I)))
  
  #
  Y.mt <- parm$Y[parm$row.subset.I,]
  
  for (ss in 1:parm$clust$K)
    {subset_log.ss.mt[ss,] <- element_fn.log.lik(ss, Y.mt, parm)
    }
  
  subset_log.ss.mt <- subset_log.ss.mt + log(prior.prob.v)
  
  subset_maxx.v <- apply(subset_log.ss.mt, 2, max)
  subset_log.ss.mt <- t(t(subset_log.ss.mt) - subset_maxx.v)
  subset_ss.mt <- exp(subset_log.ss.mt)
  
  subset_col.sums.v <- colSums(subset_ss.mt)
  subset_ss.mt <- t(t(subset_ss.mt)/subset_col.sums.v)
  
  # replace zeros by "small"
  small2 <- 1e-5
  subset_ss.mt[subset_ss.mt < small2] <- small2
  
  # again normalize
  subset_col.sums.v <- colSums(subset_ss.mt)
  subset_ss.mt <- t(t(subset_ss.mt)/subset_col.sums.v)
  
  parm$clust$element_subset_post.prob.mt <- subset_ss.mt
  dimnames(parm$clust$element_subset_post.prob.mt) <- list(1:parm$clust$K, 1:length(parm$row.subset.I))
  
  ### now compute the delta-neighborhoods
  
  relative_I <- 1:length(parm$row.subset.I)
  
  first <- TRUE
  while (length(relative_I)>=1)
    {tmp <- fast_element_fn.nbhd(relative_I, parm, max.row.nbhd.size)
    relative_k <- tmp[[1]]
    relative_I.k <- tmp[[2]]
    relative_I <- tmp[[3]]
    #
    
    if (first) 
      {parm$clust$row.nbhd <- list(parm$row.subset.I[relative_I.k])
      parm$clust$row.nbhd.k <- parm$row.subset.I[relative_k]
      parm$clust$row.nbhd_probs.k <- parm$clust$element_subset_post.prob.mt[,relative_k]
        
      first <- FALSE
    } 
    else 
      {parm$clust$row.nbhd <- c(parm$clust$row.nbhd, list(parm$row.subset.I[relative_I.k]))
      parm$clust$row.nbhd.k <- c(parm$clust$row.nbhd.k, parm$row.subset.I[relative_k])
      parm$clust$row.nbhd_probs.k <- cbind(parm$clust$row.nbhd_probs.k, parm$clust$element_subset_post.prob.mt[,relative_k])
      }
  }
  
  
  parm
}



element_fn.nbhd <- function(I, parm, max.row.nbhd.size)
	{if (length(I)>1) 
		{k <- sample(I, size=1)
		}
	if (length(I)==1) 
		{k <- I
		}

       H.v <- rep(Inf,parm$clust$N) 

	 post.prob.mt <- parm$clust$element_post.prob.mt

	 tmp1.mt <- matrix(post.prob.mt[,I], ncol=length(I))
	 tmp2.v <- post.prob.mt[,k]
	 tmp3.mt <- sqrt(tmp1.mt * tmp2.v)
	 H.v[I] <-  2*(1-colSums(tmp3.mt))

	 cutoff <- parm$row.delta 
	 I.k <- which(H.v <= cutoff)

	 
	if (length(I.k) > max.row.nbhd.size)
		{I.k <- which(rank(H.v, ties="random") <= max.row.nbhd.size)
		}

	 I.k <- sort(I.k)

       I <- sort(setdiff(I, I.k))
       I <- sort(I)

       list(k, I.k, I)

	}


element_fn.superfast.DP.iter <- function(cc, parm)
{	
  parm$k <- parm$clust$row.nbhd.k[cc]
  parm$I.k <- parm$clust$row.nbhd[[cc]]
  
  k <- parm$k
	I.k <- parm$I.k
	
	parm$clust$post.k <- parm$clust$row.nbhd_probs.k[,cc]
	
	new.s.k <- sample(1:parm$clust$K, size=length(parm$I.k), replace=TRUE, prob=parm$clust$post.k)
				
	parm$clust$s.v[I.k] <- new.s.k
	
	err <- element_fn.consistency.check(parm)
	if (err > 0)
		{stop(paste("GIBBS STEP - 1: failed consistency check: err=",err))
		}

	parm
}

element_fn.fast.DP <- function(parm, max.row.nbhd.size, row.frac.probes)
{		

	if (row.frac.probes < 1)
		{parm$row.subset.I <- sort(sample(1:parm$clust$N, round(row.frac.probes*parm$clust$N)))
		}

	if (row.frac.probes == 1)
		{parm$row.subset.I <- 1:parm$clust$N
		}

	# compute delta-neighborhoods

 	parm <- fast_element_fn.post.prob.and.delta(parm, max.row.nbhd.size)

	err <- element_fn.consistency.check(parm)
	if (err > 0)
		{stop(paste("PURE_DP MAIN: failed consistency check: err=",err))
		}
	
	num.nbhds <- length(parm$clust$row.nbhd)
	
	# M-H move for random effects of delta-nieghborhoods

  for (cc in 1:num.nbhds)
		{

    parm <- element_fn.superfast.DP.iter(cc, parm)
		 
		}

	err <- element_fn.compact_consistency.check(parm)
	if (err > 0)
		{stop(paste("PURE_DP MAIN END: failed consistency check: err=",err))
		}

	parm
	}



