
# See the "README" file on https://github.com/sguha-lab/BaCon/edit/master/README.md

rm(list=ls())

options(warn=0)

library(MASS)
library(stats) 
library(mvtnorm)

options(error=recover)

source("gen.clust.R")
source("gen.X.R")
source("iterations.R")
source("elementwise_main.R")
source("elementwise_functions.R")
source("PDP_functions.R")
source("PDP_drop.R")


fn.simulation <- function(n.burn, n.postburn, num.reps, p, n, true.r.v)
{
  # for binary covariates 
  K0 = 2
  
  num.r <- length(true.r.v)

  ######## OUTPUT OBJECTS STORAGE ###########
  
  d_credible.ar <- array(,c(num.r,2,num.reps))

	lower_log.BF.mt <- se_lower_log.BF.mt <- array(,c(num.r,num.reps))

	mean.SqFrob.mt <- se_mean.SqFrob.mt <- array(,c(num.r,num.reps))

	####### FAST MCMC PARAMETERS
	
	max.row.nbhd.size <- round(.1*n*p^.5) 
	max.col.nbhd.size <- round(.05*p) 
	
	row.frac.probes <- .1
	col.frac.probes <- .01
	
	prob.compute.col.nbhd =.01
	
	###################################
	
  for (yyy in 1:num.reps)
  for (xxx in 1:num.r)
      {
      
      ######################################
      # generate true_parm and covariates
      ######################################
    
      true_parm = fn.gen_clust(K0, p, n)
        
      true_parm$r <- true.r.v[xxx]
      
      tmp = fn.gen.X(true_parm, p, n)
      true_parm = tmp[[1]]
      data = tmp[[2]]
     
      #############################################
      # Detect clusters.true_parm is only 
      # used to evaluate clustering accuracy 
      #############################################
      
      All.Stuff.1 <- fn.mcmc(text="BURNIN...", input.All.Stuff=NULL, do.burn=TRUE, do.postburn=FALSE, n.burn, n.postburn, data, max.row.nbhd.size, max.col.nbhd.size, row.frac.probes, col.frac.probes, prob.compute.col.nbhd,  true_parm)
      
      All.Stuff <- fn.mcmc(text="POST-BURNIN...", input.All.Stuff=All.Stuff.1, do.burn=FALSE, do.postburn=TRUE, n.burn, n.postburn, data, max.row.nbhd.size, max.col.nbhd.size, row.frac.probes, col.frac.probes, prob.compute.col.nbhd,  true_parm)
      
      d_credible.v <- quantile(All.Stuff$d.v, prob=c(.025,.975))
      lower_log.BF <- All.Stuff$lower_log.BF
      se_lower_log.BF <- sd(All.Stuff$log.BF.v)/sqrt(n.postburn)
      
      mean.SqFrob <- mean(All.Stuff$SqFrob.v)
      se_mean.SqFrob <- sd(All.Stuff$SqFrob.v)/sqrt(n.postburn)
      
      d_credible.ar[xxx,,yyy] <- d_credible.v
      lower_log.BF.mt[xxx,yyy] <- lower_log.BF
      se_lower_log.BF.mt[xxx,yyy] <- se_lower_log.BF
      
      mean.SqFrob.mt[xxx,yyy] <- mean.SqFrob
      se_mean.SqFrob.mt[xxx,yyy] <- se_mean.SqFrob
      
      print("***************************")
      print(paste("END REP",yyy,", r=",true.r.v[xxx],date(),"***********"))
      print("***************************")
    
      } # end massive loop in xxx,yyy

  out = NULL
  
  out$d_credible.ar <- d_credible.ar
  out$lower_log.BF.mt <- lower_log.BF.mt
  out$se_lower_log.BF.mt <- se_lower_log.BF.mt
  
  out$mean.SqFrob.mt <- mean.SqFrob.mt
  out$se_mean.SqFrob.mt <- se_mean.SqFrob.mt
  
  out
}

out = fn.simulation(n.burn, n.postburn, num.reps, p, n, true.r.v)

# output

print("*****************************")
print("*******RESULTS *********")
print("*****************************")
print("******* proportion of correctly clustered covariate pairs **********")

print((1-apply(out$mean.SqFrob.mt,1,mean,na.rm=TRUE))*100)

print("*****************************")
print("*******  lower bound of the log-Bayes factor (PDP versus DP) **********")

print(apply(out$lower_log.BF.mt,1,mean,na.rm=TRUE))

print("*****************************")
print("******** 95% CI for PDP discount parameter *********")

print(apply(out$d_credible.ar,1:2,mean,na.rm=TRUE))




 